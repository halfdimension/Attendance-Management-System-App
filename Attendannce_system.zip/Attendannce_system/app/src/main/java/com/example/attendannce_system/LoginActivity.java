package com.example.attendannce_system;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private static final String PREFS_NAME = "UserPrefs";

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;

    private static final String[] VALID_USERNAMES = {"admin", "user1", "user2", "user3"};
    private static final String[] VALID_PASSWORDS = {"admin", "pass1", "pass2", "pass3"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(view -> {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            if (isValidCredentials(username, password)) {
                SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
                editor.putString("username", username);
                editor.apply();

                Intent intent = new Intent(LoginActivity.this, AttendanceActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean isValidCredentials(String username, String password) {
        for (int i = 0; i < VALID_USERNAMES.length; i++) {
            if (username.equals(VALID_USERNAMES[i]) && password.equals(VALID_PASSWORDS[i])) {
                return true;
            }
        }
        return false;
    }
}
