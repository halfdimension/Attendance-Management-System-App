package com.example.attendannce_system;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {
    private Context context;
    private List<Student> studentList;
    private OnStudentClickListener clickListener;

    public interface OnStudentClickListener {
        void onStudentClick(int position);
    }

    public StudentAdapter(Context context, List<Student> studentList, OnStudentClickListener clickListener) {
        this.context = context;
        this.studentList = studentList;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_student, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Student student = studentList.get(position);
        holder.bind(student);
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView studentNameTextView;
        private CheckBox attendanceCheckBox;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            studentNameTextView = itemView.findViewById(R.id.studentNameTextView);
            attendanceCheckBox = itemView.findViewById(R.id.attendanceCheckBox);
            itemView.setOnClickListener(this);
        }

        public void bind(Student student) {
            String studentInfo = student.getName() + " (" + student.getId() + ")";
            studentNameTextView.setText(studentInfo);
            attendanceCheckBox.setChecked(student.isSelected());
        }


        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION) {
                clickListener.onStudentClick(position);
            }
        }
    }
}
