package com.example.attendannce_system;

import android.os.Parcel;
import android.os.Parcelable;

public class Student implements Parcelable {
    private String id;
    private String name;
    private boolean isSelected; // Change variable name to isSelected

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.isSelected = false; // Initialize to false by default
    }

    protected Student(Parcel in) {
        id = in.readString();
        name = in.readString();
        isSelected = in.readByte() != 0; // Read the boolean value from the Parcel
    }

    public static final Creator<Student> CREATOR = new Creator<Student>() {
        @Override
        public Student createFromParcel(Parcel in) {
            return new Student(in);
        }

        @Override
        public Student[] newArray(int size) {
            return new Student[size];
        }
    };

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public boolean isSelected() {
        return isSelected; // Corrected method name to isSelected
    }

    public void toggleSelected() {
        isSelected = !isSelected; // Corrected method name to isSelected
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
        dest.writeByte((byte) (isSelected ? 1 : 0)); // Write the boolean value to the Parcel
    }
}
