package com.example.attendannce_system;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class AttendanceActivity extends AppCompatActivity implements StudentAdapter.OnStudentClickListener {
    private RecyclerView studentRecyclerView;
    private Button saveAttendanceButton;
    private List<Student> studentList;
    private StudentAdapter studentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        studentRecyclerView = findViewById(R.id.studentRecyclerView);
        saveAttendanceButton = findViewById(R.id.saveAttendanceButton);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        studentRecyclerView.setLayoutManager(layoutManager);

        studentList = new ArrayList<>();

        String loggedInUser = getLoggedInUser();
        if ("admin".equals(loggedInUser)) {
            // Load admin's student list
            studentList.add(new Student("21BCS7459", "Eakansh"));
            studentList.add(new Student("21BCS10003", "Harshit Bamotra"));
            studentList.add(new Student("21BCS10003", "Harshit Bamotra"));
            studentList.add(new Student("21BCS7243", "Sagar Nailwal"));
            studentList.add(new Student("21BCS7240", "Tirukala Gowtham"));
            studentList.add(new Student("21BCS10095", "Shashank Kumar"));
            studentList.add(new Student("21BCS4792", "Dipesh Ranjan"));
            studentList.add(new Student("21BCS7723", "Dinesh Kumar sahoo"));
            studentList.add(new Student("21bcs9980", "Aditya Bhatt"));
            studentList.add(new Student("21BCS9273", "Shivangi Gagneja"));
            studentList.add(new Student("21BCS9345", "Guladab Bawa"));
            studentList.add(new Student("21BCS7390", "Arzoo"));
            studentList.add(new Student("21BCS8238", "Riya Khandelwal"));
            studentList.add(new Student("21BCS5878", "Piyush Sharma"));
            studentList.add(new Student("21BCS5921", "Radhika"));
            studentList.add(new Student("21BCS5550", "Bhumi"));
            studentList.add(new Student("21BCS5855", "Parth Singh"));
            studentList.add(new Student("21BCS5693", "Krish Goyal"));
            studentList.add(new Student("21BCS5710", "Rahul Chhapola"));

            // Add more students as needed
        } else if ("user1".equals(loggedInUser)) {
            // Load user1's student list
            studentList.add(new Student("21BCS7093", "Shashi Ranjan Mehta"));
            studentList.add(new Student("21BCS7986", "Daksh Srivastava"));
            studentList.add(new Student("21BCS8458", "Harsh Mudgil"));
            studentList.add(new Student("21BCS8236", "Akriti Thakur"));
            studentList.add(new Student("21BCS7885", "Gagan Ajit Singh"));
            studentList.add(new Student("21BCS9507", "Aditya Kumar Singh"));
            studentList.add(new Student("21BCS9802", "SACHIN KUMAR SACHAN"));
            studentList.add(new Student("21BCS5034", "Abhishek Kumar"));
            studentList.add(new Student("21BCS7988", "Arjun"));
            studentList.add(new Student("21BCS7980", "Arjun ka dost"));
            studentList.add(new Student("21BCS9058", "Richa Saurabh"));
            studentList.add(new Student("21BCS8208", "Himani Sharma"));

            // Add more students as needed
        } else if ("user2".equals(loggedInUser)) {
            // Load user2's student list
            studentList.add(new Student("21BCS1029", "Jalani Aniruddh"));
            studentList.add(new Student("21BCS2142", "Raghav Sharma"));
            studentList.add(new Student("21BCS3587", "Sumedha Musib"));

            studentList.add(new Student("21BCS1701", "Nikhil sharma"));
            studentList.add(new Student("21BCS1721", "Sneha Kumari"));
            studentList.add(new Student("21BCS1559", "Bilal Ahmad"));

            studentList.add(new Student("21BCS1883", "Sanskar Srivastava"));
            studentList.add(new Student("21BCS1821", "Divyanshu Raj"));
            studentList.add(new Student("21BCS2729", "Veerpal Kaur"));

            studentList.add(new Student("21BCS1901", "Rishujeet Rai"));
            studentList.add(new Student("21BCS1025", "Ujala Srivastava"));

            studentList.add(new Student("21bcs2008", "Prashant Kumar Singh"));
            studentList.add(new Student("21bcs3681", "Arav Kumar Prasad"));

            studentList.add(new Student("21BCS3148", "Mehul"));
            studentList.add(new Student("21BCS3231", "Himanshu Kumar"));
            studentList.add(new Student("21BCS3240", "Ayush sharan Gaur"));



            // Add more students as needed
        } else if ("user3".equals(loggedInUser)) {
            // Load user3's student list
            studentList.add(new Student("21BCS2977", "Vansh Nanda"));
            studentList.add(new Student("21BCS2983", "Kalash Singh"));
            studentList.add(new Student("21BCS2968", "Mridul Garg"));

            studentList.add(new Student("21BCS1012", "Deepanshu Gupta"));
            studentList.add(new Student("21BCS2620", "Abhay Dutt"));

            studentList.add(new Student("21BCS4266", "Anshuman Raturi"));
            studentList.add(new Student("21BCS4117", "Aarush Kashyap"));
            studentList.add(new Student("21BCS4764", "Keshav Saini"));

            studentList.add(new Student("21BCS3381", "Esha Narula"));
            studentList.add(new Student("21BCS3645", "Piyush Rana"));
            studentList.add(new Student("21BCS2974", "Prachi"));

            studentList.add(new Student("21BCS4250", "Naman"));
            studentList.add(new Student("21BCS4207", "Japneet Singh"));
            studentList.add(new Student("21BCS4197", "Tushar Parakh"));

            studentList.add(new Student("21BCS2640", "Riya Mishra"));
            studentList.add(new Student("21BCS2739", "Shibam Dey"));
            studentList.add(new Student("21BCS2769", "Arnav Savant"));

            studentList.add(new Student("Arjun Hari K", "Arjun Hari K"));

            studentList.add(new Student("21BCS2821", "Perumandla Rohith Goud"));
            // Add more students as needed
        }

        // Add more else if conditions for other users

        studentAdapter = new StudentAdapter(this, studentList, this);
        studentRecyclerView.setAdapter(studentAdapter);

        saveAttendanceButton.setOnClickListener(view -> {
            saveAttendance();
        });
    }

    private void saveAttendance() {
        SharedPreferences sharedPreferences = getSharedPreferences("AttendancePrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        for (Student student : studentList) {
            if (student.isSelected()) {
                editor.putBoolean(student.getId(), true);
            }
        }
        editor.apply();
        Toast.makeText(this, "Attendance saved", Toast.LENGTH_SHORT).show();
        openPresentStudentsActivity();
    }

    private void openPresentStudentsActivity() {
        // Filter out the present students
        List<Student> presentStudents = new ArrayList<>();
        SharedPreferences sharedPreferences = getSharedPreferences("AttendancePrefs", Context.MODE_PRIVATE);
        for (Student student : studentList) {
            if (isStudentPresent(student.getId())) {
                presentStudents.add(student);
            }
        }

        // Create intent and pass the list of present students to PresentStudentsActivity
        Intent intent = new Intent(this, PresentStudentsActivity.class);
        intent.putParcelableArrayListExtra("presentStudentsList", new ArrayList<>(presentStudents));
        startActivity(intent);
    }


    private boolean isStudentPresent(String studentId) {
        SharedPreferences sharedPreferences = getSharedPreferences("AttendancePrefs", Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(studentId, false);
    }

    private String getLoggedInUser() {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        return prefs.getString("username", "admin");
    }

    @Override
    public void onStudentClick(int position) {
        studentList.get(position).toggleSelected();
        studentAdapter.notifyItemChanged(position);
    }
}
