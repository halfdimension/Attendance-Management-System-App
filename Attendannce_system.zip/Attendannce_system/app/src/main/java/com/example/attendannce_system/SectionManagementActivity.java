package com.example.attendannce_system;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SectionManagementActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_section_management);

        // Example: Displaying section details
        String sectionName = "Section A";
        int numberOfStudents = 30; // Example: Number of students in the section
        TextView sectionDetailsTextView = findViewById(R.id.sectionDetailsTextView);
        sectionDetailsTextView.setText("Section Name: " + sectionName + "\nNumber of Students: " + numberOfStudents);
    }
}
