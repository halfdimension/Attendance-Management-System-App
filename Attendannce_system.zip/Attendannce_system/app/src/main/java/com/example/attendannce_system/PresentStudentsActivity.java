package com.example.attendannce_system;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class PresentStudentsActivity extends AppCompatActivity {
    private RecyclerView presentStudentsRecyclerView;
    private List<Student> presentStudentsList;
    private StudentAdapter presentStudentsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_present_students);

        // Get the student list passed from AttendanceActivity
        presentStudentsList = getIntent().getParcelableArrayListExtra("presentStudentsList");

        presentStudentsRecyclerView = findViewById(R.id.presentStudentsRecyclerView);

        // Initialize RecyclerView with a layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        presentStudentsRecyclerView.setLayoutManager(layoutManager);

        // Initialize adapter with present students list
        presentStudentsAdapter = new StudentAdapter(this, presentStudentsList, null);

        presentStudentsRecyclerView.setAdapter(presentStudentsAdapter);
    }
}
